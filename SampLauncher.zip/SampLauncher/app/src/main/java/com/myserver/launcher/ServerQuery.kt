package com.myserver.launcher

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/** کوئری استاندارد SA-MP (opcode 'i'): تعداد بازیکن آنلاین و ظرفیت سرور */
object ServerQuery {
    data class Info(val players: Int, val maxPlayers: Int)

    fun query(host: String, port: Int): Info? = try {
        val addr = InetAddress.getByName(host)
        val ip = addr.address
        val req = ByteArray(11)
        "SAMP".toByteArray().copyInto(req, 0)
        ip.copyInto(req, 4)
        req[8] = (port and 0xFF).toByte()
        req[9] = ((port shr 8) and 0xFF).toByte()
        req[10] = 'i'.code.toByte()

        DatagramSocket().use { s ->
            s.soTimeout = 2500
            s.send(DatagramPacket(req, req.size, addr, port))
            val buf = ByteArray(512)
            val pkt = DatagramPacket(buf, buf.size)
            s.receive(pkt)
            fun le16(o: Int) = (buf[o].toInt() and 0xFF) or ((buf[o + 1].toInt() and 0xFF) shl 8)
            Info(le16(12), le16(14))
        }
    } catch (e: Exception) { null }
}
