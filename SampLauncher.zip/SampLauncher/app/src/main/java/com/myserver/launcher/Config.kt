package com.myserver.launcher

import android.content.Context

object Config {
    // ← اینا رو با مشخصات سرور خودت عوض کن
    const val SERVER_NAME = "نام سرور من"
    const val DEFAULT_IP = "127.0.0.1"
    const val DEFAULT_PORT = 7777
    // پکیج بازی GTA SA که کلاینت سمپ روش نصب شده
    const val GAME_PACKAGE = "com.rockstargames.gtasa"

    const val TELEGRAM_URL = "https://t.me/your_channel"
    const val DISCORD_URL = "https://discord.gg/your_invite"

    // لینک مستقیم فایل zip دیتا روی VPS خودت
    const val DATA_URL = "http://YOUR_VPS_IP/data.zip"
    // هر بار دیتا رو آپدیت کردی این رو عوض کن تا لانچر دوباره دانلودش کنه
    const val DATA_VERSION = "1"

    private fun p(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    fun nick(c: Context) = p(c).getString("nick", "") ?: ""
    fun ip(c: Context) = p(c).getString("ip", DEFAULT_IP) ?: DEFAULT_IP
    fun port(c: Context) = p(c).getInt("port", DEFAULT_PORT)
    fun save(c: Context, nick: String, ip: String, port: Int) =
        p(c).edit().putString("nick", nick).putString("ip", ip).putInt("port", port).apply()
}
