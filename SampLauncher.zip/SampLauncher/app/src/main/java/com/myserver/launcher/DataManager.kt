package com.myserver.launcher

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** دانلود zip دیتا از VPS، استخراج و نگه‌داری نسخه */
object DataManager {
    fun dataDir(c: Context): File =
        File(c.getExternalFilesDir(null) ?: c.filesDir, "gamedata")

    private fun marker(c: Context) = File(dataDir(c), ".version")

    fun isReady(c: Context): Boolean =
        marker(c).exists() && marker(c).readText().trim() == Config.DATA_VERSION

    /** روی ترد پس‌زمینه صدا بزن. onProgress(درصد, متن) */
    fun download(c: Context, onProgress: (Int, String) -> Unit) {
        val zip = File(c.cacheDir, "data.zip")
        val conn = URL(Config.DATA_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.connect()
        if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong

        conn.inputStream.use { input ->
            FileOutputStream(zip).use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var n: Int
                while (input.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n)
                    done += n
                    val pct = if (total > 0) (done * 100 / total).toInt() else 0
                    onProgress(pct, "دانلود: ${done / 1_048_576} / ${total / 1_048_576} MB")
                }
            }
        }

        onProgress(100, "در حال استخراج...")
        val dir = dataDir(c)
        dir.deleteRecursively()
        dir.mkdirs()
        val root = dir.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val f = File(dir, e.name)
                // جلوگیری از zip-slip
                if (!f.canonicalPath.startsWith(root)) throw SecurityException("bad zip entry")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zis.copyTo(it) }
                }
                e = zis.nextEntry
            }
        }
        zip.delete()
        marker(c).writeText(Config.DATA_VERSION)
    }
}
