package com.myserver.launcher

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val nick = findViewById<EditText>(R.id.etNick)
        val ip = findViewById<EditText>(R.id.etIp)
        val port = findViewById<EditText>(R.id.etPort)
        nick.setText(Config.nick(this)); ip.setText(Config.ip(this))
        port.setText(Config.port(this).toString())

        findViewById<View>(R.id.btnResetData).setOnClickListener {
            DataManager.dataDir(this).deleteRecursively()
            Toast.makeText(this, "دیتا حذف شد؛ دفعه‌ی بعد دوباره دانلود میشه", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            Config.save(this, nick.text.toString().trim(), ip.text.toString().trim(),
                port.text.toString().toIntOrNull() ?: Config.DEFAULT_PORT)
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
