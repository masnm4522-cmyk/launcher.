package com.myserver.launcher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var loading: View
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.title).text = Config.SERVER_NAME
        status = findViewById(R.id.status)
        loading = findViewById(R.id.loading)
        progress = findViewById(R.id.progress)
        progressText = findViewById(R.id.progressText)

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<View>(R.id.btnPlay).setOnClickListener { onPlay() }
        findViewById<View>(R.id.btnTelegram).setOnClickListener { open(Config.TELEGRAM_URL) }
        findViewById<View>(R.id.btnDiscord).setOnClickListener { open(Config.DISCORD_URL) }
    }

    private fun open(url: String) =
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun onPlay() {
        if (busy) return
        if (Config.nick(this).isBlank()) {
            Toast.makeText(this, R.string.need_nick, Toast.LENGTH_SHORT).show()
            return
        }
        if (DataManager.isReady(this)) {
            GameLauncher.start(this)
            return
        }
        // دیتا نیست یا قدیمیه → دانلود
        busy = true
        loading.visibility = View.VISIBLE
        Thread {
            try {
                DataManager.download(this) { pct, text ->
                    runOnUiThread { progress.progress = pct; progressText.text = text }
                }
                runOnUiThread {
                    loading.visibility = View.GONE
                    busy = false
                    GameLauncher.start(this)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading.visibility = View.GONE
                    busy = false
                    Toast.makeText(this, "خطا در دانلود دیتا: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onBackPressed() { if (!busy) super.onBackPressed() }

    override fun onResume() {
        super.onResume()
        val ip = Config.ip(this); val port = Config.port(this)
        Thread {
            val info = ServerQuery.query(ip, port)
            runOnUiThread {
                status.text = if (info != null) "آنلاین: ${info.players} / ${info.maxPlayers}"
                else getString(R.string.offline)
            }
        }.start()
    }
}
