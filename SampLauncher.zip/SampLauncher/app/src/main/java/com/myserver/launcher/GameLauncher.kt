package com.myserver.launcher

import android.content.Context
import android.widget.Toast

object GameLauncher {
    fun start(c: Context) {
        val intent = c.packageManager.getLaunchIntentForPackage(Config.GAME_PACKAGE)
        if (intent == null) {
            Toast.makeText(c, R.string.game_missing, Toast.LENGTH_LONG).show()
            return
        }
        // اطلاعات اتصال رو به کلاینت می‌دیم. اینکه کلاینت سمپ شما اینا رو
        // از intent بخونه یا از فایل تنظیمات (مثلاً settings.ini تو پوشه‌ی بازی)،
        // بستگی به خود کلاینت داره؛ این قسمت رو با اون هماهنگ کن.
        intent.putExtra("nickname", Config.nick(c))
        intent.putExtra("server_ip", Config.ip(c))
        intent.putExtra("server_port", Config.port(c))
        intent.putExtra("data_path", DataManager.dataDir(c).absolutePath)
        c.startActivity(intent)
    }
}
