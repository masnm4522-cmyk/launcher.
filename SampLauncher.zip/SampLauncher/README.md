# لانچر سمپ
1. پوشه رو تو Android Studio باز کن (Open) و صبر کن Gradle سینک بشه.
2. فایل app/src/main/java/com/myserver/launcher/Config.kt رو با مشخصات سرورت عوض کن
   (SERVER_NAME, DEFAULT_IP, DEFAULT_PORT, GAME_PACKAGE).
3. GAME_PACKAGE رو تو AndroidManifest.xml (بخش queries) هم یکی کن.
4. Build > Build APK.
