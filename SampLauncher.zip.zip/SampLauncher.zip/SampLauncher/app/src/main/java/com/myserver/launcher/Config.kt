package com.myserver.launcher

import android.content.Context

object Config {
    // ← اینا رو با مشخصات سرور خودت عوض کن
    const val SERVER_NAME = "RoyalCity RPG"
    const val DEFAULT_IP = "5.57.34.81"
    const val DEFAULT_PORT = 7777
    // پکیج بازی GTA SA که کلاینت سمپ روش نصب شده
    const val GAME_PACKAGE = "com.sampmobilerp.game"

    const val WEBSITE_URL = "https://srsamp.ir"
    const val TELEGRAM_URL = "" // خالی = دکمه مخفی میشه
    const val DISCORD_URL = "" // خالی = دکمه مخفی میشه

    // لینک مستقیم فایل APK بازی روی VPS خودت
    const val APK_URL = "https://srsamp.ir/game.apk"
    // نسخه‌ی APK (versionName). هر وقت APK جدید گذاشتی این رو عوض کن تا بازیکن‌ها آپدیت بگیرن
    const val GAME_VERSION = "1.0.6"

    private fun p(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    fun nick(c: Context) = p(c).getString("nick", "") ?: ""
    fun ip(c: Context) = p(c).getString("ip", DEFAULT_IP) ?: DEFAULT_IP
    fun port(c: Context) = p(c).getInt("port", DEFAULT_PORT)
    fun save(c: Context, nick: String, ip: String, port: Int) =
        p(c).edit().putString("nick", nick).putString("ip", ip).putInt("port", port).apply()
}
