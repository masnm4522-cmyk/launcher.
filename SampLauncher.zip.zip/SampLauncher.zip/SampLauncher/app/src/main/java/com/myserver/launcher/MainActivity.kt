package com.myserver.launcher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var avatar: TextView
    private lateinit var nickText: TextView
    private lateinit var addr: TextView
    private lateinit var loading: View
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.title).text = Config.SERVER_NAME
        status = findViewById(R.id.status)
        avatar = findViewById(R.id.avatar)
        nickText = findViewById(R.id.nickText)
        addr = findViewById(R.id.addr)
        findViewById<View>(R.id.profileBox).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        loading = findViewById(R.id.loading)
        progress = findViewById(R.id.progress)
        progressText = findViewById(R.id.progressText)

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<View>(R.id.btnPlay).setOnClickListener { onPlay() }
        bindLink(R.id.btnSite, Config.WEBSITE_URL)
        bindLink(R.id.btnTelegram, Config.TELEGRAM_URL)
        bindLink(R.id.btnDiscord, Config.DISCORD_URL)
    }

    private fun bindLink(id: Int, url: String) {
        val v = findViewById<View>(id)
        if (url.isBlank()) v.visibility = View.GONE
        else v.setOnClickListener { open(url) }
    }

    private fun open(url: String) =
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun onPlay() {
        if (busy) return
        if (Config.nick(this).isBlank()) {
            Toast.makeText(this, R.string.need_nick, Toast.LENGTH_SHORT).show()
            return
        }
        if (ApkManager.isUpToDate(this)) {
            GameLauncher.start(this)
            return
        }
        // دیتا نیست یا قدیمیه → دانلود
        busy = true
        loading.visibility = View.VISIBLE
        Thread {
            try {
                ApkManager.download(this) { pct, text ->
                    runOnUiThread { progress.progress = pct; progressText.text = text }
                }
                runOnUiThread {
                    loading.visibility = View.GONE
                    busy = false
                    if (!ApkManager.install(this))
                        Toast.makeText(this, "اجازه‌ی نصب رو بده و دوباره «ورود به بازی» رو بزن", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading.visibility = View.GONE
                    busy = false
                    Toast.makeText(this, "خطا در دانلود بازی: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onBackPressed() { if (!busy) super.onBackPressed() }

    override fun onResume() {
        super.onResume()
        val ip = Config.ip(this); val port = Config.port(this)
        val nick = Config.nick(this)
        nickText.text = if (nick.isBlank()) "نام بازیکن را وارد کن" else nick
        avatar.text = if (nick.isBlank()) "؟" else nick.first().uppercase()
        addr.text = "$ip:$port"
        Thread {
            val t0 = System.currentTimeMillis()
            val info = ServerQuery.query(ip, port)
            val ping = System.currentTimeMillis() - t0
            runOnUiThread {
                status.text = if (info != null)
                    "آنلاین: ${info.players} / ${info.maxPlayers}   •   پینگ: ${ping}ms"
                else getString(R.string.offline)
            }
        }.start()
    }
}
