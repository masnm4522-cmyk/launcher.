package com.myserver.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** دانلود APK بازی از VPS و نصب آن؛ اجرای بازی فقط وقتی نسخه‌ی درست نصب باشد */
object ApkManager {
    fun apkFile(c: Context) =
        File(c.getExternalFilesDir("apk") ?: c.cacheDir, "game.apk").also { it.parentFile?.mkdirs() }

    private fun installedVersion(c: Context): String? = try {
        c.packageManager.getPackageInfo(Config.GAME_PACKAGE, 0).versionName
    } catch (e: PackageManager.NameNotFoundException) { null }

    fun isUpToDate(c: Context) = installedVersion(c) == Config.GAME_VERSION

    fun download(c: Context, onProgress: (Int, String) -> Unit) {
        val out = apkFile(c)
        val conn = URL(Config.APK_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.connect()
        if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            FileOutputStream(out).use { o ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var n: Int
                while (input.read(buf).also { n = it } != -1) {
                    o.write(buf, 0, n)
                    done += n
                    val pct = if (total > 0) (done * 100 / total).toInt() else 0
                    onProgress(pct, "دانلود: ${done / 1_048_576} / ${total / 1_048_576} MB")
                }
            }
        }
    }

    /** false یعنی اول باید اجازه‌ی «نصب از این منبع» داده شود */
    fun install(c: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls()) {
            c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return false
        }
        val uri = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", apkFile(c))
        c.startActivity(Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
